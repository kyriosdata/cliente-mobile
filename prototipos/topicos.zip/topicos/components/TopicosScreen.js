import React, { Component } from 'react';
import {
  FlatList,
  StyleSheet,
  Text,
  View,
  TouchableWithoutFeedback,
} from 'react-native';

export default class TopicosScreen extends Component {
  static navigationOptions = {
    title: 'Saiba de tudo',
  };

  separador = () => {
    return (
      <View
        style={{
          height: 0.5,
          width: '96%',
          backgroundColor: '#CED0CE',
          marginLeft: '2%',
        }}
      />
    );
  };

  render() {
    return (
      <View style={styles.container}>
        <View style={styles.listaTopicos}>
          <FlatList
            data={[
              { key: 'Futebol', titulo: 'Tópico 1' },
              { key: 'Tênis', titulo: 'Tópico 2' },
              { key: 'Natação', titulo: 'Tópico 3' },
              { key: 'Basquete', titulo: 'Tópico 4' },
              { key: 'Volei', titulo: 'Tópico 5' },
              { key: 'Política', titulo: 'Tópico 6' },
              { key: 'Tecnologia', titulo: 'Tópico 7' },
              { key: 'Saúde', titulo: 'Tópico 8' },
              { key: 'Família', titulo: 'Tópico 9' },
              { key: 'Escola', titulo: 'Tópico 10' },
              { key: 'Universidade', titulo: 'Tópico 11' },
              { key: 'Emprego', titulo: 'Tópico 12' },
              { key: 'Cinema', titulo: 'Tópico 13' },
              { key: 'Alimentação', titulo: 'Tópico 14' },
            ]}
            renderItem={({ item }) => (
              <TouchableWithoutFeedback
                onPress={() => this.props.navigation.navigate('Noticias', { titulo : item.titulo, key : item.key })}>
                <View style={styles.topico}>
                  <Text style={styles.titulo}>{item.titulo}</Text>
                  <Text style={styles.item}>{item.key}</Text>
                </View>
              </TouchableWithoutFeedback>
            )}
            ItemSeparatorComponent={this.separador}
          />
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  listaTopicos: {
    flex: 1,
    paddingTop: 10,
    justifyContent: 'center',
  },
  topico: {
    paddingLeft: 10,
    justifyContent: 'center',
    height: 60,
  },
  titulo: {
    paddingLeft: 10,
    fontSize: 12,
  },
  item: {
    paddingLeft: 10,
    fontSize: 18,
  },
});

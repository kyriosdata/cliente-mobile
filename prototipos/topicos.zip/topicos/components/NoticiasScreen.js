import React, { Component } from 'react';
import { FlatList, StyleSheet, Button, Text, View } from 'react-native';
import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';

export default class NoticiasScreen extends React.Component {
  static navigationOptions = ({ navigation }) => {
    return {
      title: navigation.getParam('key', 'não fornecido')
    };
  };

  render() {
    return (
      <View>
        <Text>{this.props.navigation.getParam('titulo', 'NAO DETECTADO')}</Text>
      </View>
    );
  }
}

import React, { Component } from 'react';
import { FlatList, StyleSheet, Button, Text, View } from 'react-native';
import TopicosScreen from './components/TopicosScreen';
import NoticiasScreen from './components/NoticiasScreen';
import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';

const App = createStackNavigator(
  {
    Topicos: TopicosScreen,
    Noticias: NoticiasScreen
  },
  {
    initialRouteName: 'Topicos'
  }
);

export default createAppContainer(App);

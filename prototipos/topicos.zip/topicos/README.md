# cliente-mobile

App que exibe tópicos contendo notícias e, onde cada uma delas, é formada
por texto e imagens.
